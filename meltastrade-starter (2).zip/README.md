# Meltastrade starter

A fresh Next.js starter for a Deriv market-analysis and signal-research dashboard.

## Included
- Responsive dashboard shell for mobile and desktop
- Market selector with illustrative Volatility index cards
- Placeholder chart and signal-research panel
- Navigation placeholders for charts, signals, digit analysis, bot builder, risk calculator, and reports
- No order placement or trade execution

## Important data notice
All prices, changes, and the chart in this starter are illustrative placeholders. They are not live quotes, verified signals, or trading advice.

## Run locally
1. Install Node.js 20.9 or newer.
2. Extract this folder.
3. Open a terminal in the project folder.
4. Run `npm install`
5. Run `npm run dev`
6. Open `http://localhost:3000`

## Deploy to Netlify
1. Push the project to a new GitHub repository.
2. In Netlify, choose **Add new site → Import an existing project**.
3. Select the new GitHub repository.
4. Build command: `npm run build`
5. Publish directory: leave blank for the Next.js Runtime/plugin to manage.
6. Deploy and check the build log.

## Next implementation steps
1. Add Deriv public market-data WebSocket integration (`active_symbols`, `ticks`, `ticks_history`).
2. Compute transparent, configurable indicators from real market data.
3. Add signal history and backtesting with clear methodology.
4. Add Deriv OAuth only if/when user-account features are needed. Use the official OAuth 2.0 Authorization Code + PKCE flow and keep token exchange server-side.
5. Keep all trading/order endpoints disabled for the analysis-only release.

## Security
Never commit API tokens, OAuth client secrets, `.env` files, or user access tokens to GitHub. Do not ask users to paste passwords or tokens into the dashboard.
