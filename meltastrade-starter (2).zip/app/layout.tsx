import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Meltastrade | Market Analysis",
  description: "Market analysis and educational signals dashboard.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
