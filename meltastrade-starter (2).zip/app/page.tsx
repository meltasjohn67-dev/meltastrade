"use client";

import { useMemo, useState } from "react";
import {
  Activity, BarChart3, Bot, CandlestickChart, CircleHelp, Gauge,
  LayoutDashboard, Menu, MessageCircle, Search, ShieldCheck, TrendingUp,
  X, Layers3, ChartNoAxesCombined
} from "lucide-react";

const markets = [
  { name: "Volatility 10 Index", symbol: "R_10", change: "+0.42%", price: "1,245.83", positive: true },
  { name: "Volatility 25 Index", symbol: "R_25", change: "-0.18%", price: "2,891.46", positive: false },
  { name: "Volatility 50 Index", symbol: "R_50", change: "+0.73%", price: "4,120.12", positive: true },
  { name: "Volatility 75 Index", symbol: "R_75", change: "+0.21%", price: "6,742.90", positive: true },
  { name: "Volatility 100 Index", symbol: "R_100", change: "-0.35%", price: "9,531.24", positive: false },
];

const navItems = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "Charts & Markets", icon: CandlestickChart },
  { label: "Signals", icon: Activity },
  { label: "Digit Analysis", icon: BarChart3 },
  { label: "Bot Builder", icon: Bot },
  { label: "Risk Calculator", icon: Gauge },
  { label: "Reports", icon: ChartNoAxesCombined },
];

export default function Home() {
  const [active, setActive] = useState("Overview");
  const [selectedMarket, setSelectedMarket] = useState("R_75");
  const [mobileNav, setMobileNav] = useState(false);
  const market = useMemo(() => markets.find((m) => m.symbol === selectedMarket) ?? markets[3], [selectedMarket]);

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><ChartNoAxesCombined size={22} /></div>
          <div><strong>MELTASTRADE</strong><span>MARKET INTELLIGENCE</span></div>
          <button className="icon-button close-nav" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <div className="nav-caption">WORKSPACE</div>
        <nav>
          {navItems.map((item) => {
            const Icon = item.icon;
            return <button key={item.label} className={`nav-item ${active === item.label ? "active" : ""}`} onClick={() => { setActive(item.label); setMobileNav(false); }}>
              <Icon size={18} /><span>{item.label}</span>{item.label === "Signals" && <i className="nav-dot" />}
            </button>;
          })}
        </nav>
        <div className="sidebar-bottom">
          <div className="safe-card"><ShieldCheck size={18}/><div><b>Analysis mode</b><span>No trades are placed</span></div></div>
          <button className="nav-item"><CircleHelp size={18}/><span>Help & support</span></button>
          <div className="version">Meltastrade preview · v0.1</div>
        </div>
      </aside>

      <section className="main-panel">
        <header className="topbar">
          <button className="icon-button menu-button" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={21}/></button>
          <div className="crumb"><span>Workspace</span><b>/</b><strong>{active}</strong></div>
          <div className="top-actions"><div className="search-box"><Search size={16}/><span>Search markets...</span><kbd>⌘ K</kbd></div><div className="status"><i/> Public market preview</div></div>
        </header>

        <div className="content">
          <section className="welcome-row">
            <div><div className="eyebrow"><span className="eyebrow-line"/>DERIV MARKET ANALYTICS</div><h1>{active === "Overview" ? "Market overview" : active}</h1><p>One workspace for market data, technical analysis and signal research.</p></div>
            <label className="market-select"><span>SELECT MARKET</span><select value={selectedMarket} onChange={(e) => setSelectedMarket(e.target.value)}>{markets.map(m => <option key={m.symbol} value={m.symbol}>{m.name}</option>)}</select></label>
          </section>

          <div className="notice"><Activity size={17}/><span><b>Preview data:</b> prices and percentage changes below are illustrative placeholders, not live Deriv quotes or trading signals.</span></div>

          <section className="stats-grid">
            <article className="stat-card"><div className="stat-head"><span>Selected market</span><CandlestickChart size={17}/></div><strong className="stat-value">{market.name}</strong><div className="stat-foot"><span className="muted">Symbol: {market.symbol}</span><span className="pill neutral">Preview</span></div></article>
            <article className="stat-card"><div className="stat-head"><span>Sample price</span><TrendingUp size={17}/></div><strong className="stat-value">{market.price}</strong><div className="stat-foot"><span className="muted">Illustrative only</span><span className={`pill ${market.positive ? "up" : "down"}`}>{market.change}</span></div></article>
            <article className="stat-card"><div className="stat-head"><span>Signal status</span><Activity size={17}/></div><strong className="stat-value">Not calculated</strong><div className="stat-foot"><span className="muted">Connect market data first</span><span className="pill neutral">Waiting</span></div></article>
            <article className="stat-card"><div className="stat-head"><span>Trading mode</span><ShieldCheck size={17}/></div><strong className="stat-value">Analysis only</strong><div className="stat-foot"><span className="muted">Trade execution disabled</span><span className="pill safe">Safe mode</span></div></article>
          </section>

          <section className="content-grid">
            <article className="panel chart-panel">
              <div className="panel-heading"><div><h2>Market movement</h2><p>{market.name} · sample visualization</p></div><span className="panel-tag"><span/> Demo preview</span></div>
              <div className="chart-legend"><span><i className="legend-price"/>Illustrative price</span><span>Not live market data</span></div>
              <div className="chart-area">
                <div className="chart-y"><span>100</span><span>75</span><span>50</span><span>25</span><span>0</span></div>
                <svg viewBox="0 0 720 260" preserveAspectRatio="none" role="img" aria-label="Illustrative market line chart">
                  <defs><linearGradient id="fillArea" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#14c9a3" stopOpacity=".2"/><stop offset="100%" stopColor="#14c9a3" stopOpacity="0"/></linearGradient></defs>
                  {[20,70,120,170,220].map(y => <line key={y} x1="0" x2="720" y1={y} y2={y} stroke="currentColor" strokeOpacity=".09" strokeDasharray="4 5"/>)}
                  <path d="M0 190 L35 166 L68 177 L100 132 L135 149 L168 116 L202 137 L237 95 L270 115 L304 82 L338 105 L372 70 L407 91 L440 62 L475 88 L510 52 L543 74 L578 43 L612 61 L645 34 L680 51 L720 24 L720 260 L0 260 Z" fill="url(#fillArea)"/>
                  <path d="M0 190 L35 166 L68 177 L100 132 L135 149 L168 116 L202 137 L237 95 L270 115 L304 82 L338 105 L372 70 L407 91 L440 62 L475 88 L510 52 L543 74 L578 43 L612 61 L645 34 L680 51 L720 24" fill="none" stroke="#14c9a3" strokeWidth="2.5" vectorEffect="non-scaling-stroke"/>
                </svg>
              </div>
              <div className="chart-x"><span>09:00</span><span>10:00</span><span>11:00</span><span>12:00</span><span>13:00</span><span>14:00</span></div>
            </article>
            <article className="panel signal-panel">
              <div className="panel-heading"><div><h2>Signal research</h2><p>Rules-based analysis, not predictions</p></div><Activity size={18}/></div>
              <div className="signal-empty"><div className="signal-icon"><Activity size={23}/></div><h3>Market data not connected</h3><p>Connect the public Deriv market-data stream to calculate indicators from real ticks.</p><span className="pill neutral">No active signal</span></div>
              <div className="signal-footer"><ShieldCheck size={16}/><span>Signals can be wrong. Verify before making decisions.</span></div>
            </article>
          </section>

          <section className="panel markets-panel">
            <div className="panel-heading"><div><h2>Volatility markets</h2><p>Markets selected for the initial dashboard</p></div><button className="text-button" onClick={() => setActive("Charts & Markets")}>View market analysis →</button></div>
            <div className="market-table">
              <div className="table-row table-head"><span>MARKET</span><span>SYMBOL</span><span>SAMPLE PRICE</span><span>CHANGE</span><span>STATUS</span></div>
              {markets.map(m => <button key={m.symbol} className={`table-row market-row ${selectedMarket === m.symbol ? "selected-row" : ""}`} onClick={() => setSelectedMarket(m.symbol)}><span className="market-name"><span className="market-mini"><Activity size={15}/></span>{m.name}</span><span className="symbol">{m.symbol}</span><span className="price">{m.price}</span><span className={m.positive ? "positive" : "negative"}>{m.change}</span><span><i className="status-dot preview-dot"/>Preview</span></button>)}
            </div>
          </section>
          <footer className="footer"><span>© 2026 Meltastrade</span><span>Independent analysis tool · Not affiliated with or endorsed by Deriv</span></footer>
        </div>
      </section>
      {mobileNav && <button className="backdrop" aria-label="Close navigation" onClick={() => setMobileNav(false)} />}
    </main>
  );
}
